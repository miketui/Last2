# Command Registry Storage Instructions

## What this package contains
- `chatgpt_command_core_memory_map.docx` — human-readable overview of the core commands now suited for memory.
- `chatgpt_command_registry_v1.json` — machine-readable full registry extracted from your uploaded files.
- `command_registry_storage_instructions.md` — this instruction file.

## Where to store the registry for best results
1. Upload `chatgpt_command_registry_v1.json` to your ChatGPT File Library.
2. Keep a backup copy in your own master command-system folder, such as:
   - Google Drive / Prompt Library / Command Registry
   - Dropbox / AI Systems / Command Registry
   - Local project folder used for new builds
3. When starting a new project, either:
   - attach the registry file directly, or
   - tell me to use the command registry already in your file library.

## What is already stored in memory
These durable commands are now appropriate for memory:
- AUTO::DETECT+ROUTE
- AGM
- Normal mode
- ACTIVATE::SALES13+PROMPTLIB
- SALES13::APPLY
- PROMPTLIB::ROUTE
- PROMPTLIB::OPEN::{TITLE}::{TYPE}
- PROMPTLIB+SALES13::APPLY

## Recommended default command
Use this as your universal front-door command:

`AUTO::DETECT+ROUTE`

### What it should mean
For every input, inspect the request, decide which command, doctrine, workflow, or registry asset applies, and use that path to improve the response.

## Update workflow
Whenever you create new commands or revise old ones:
1. Ask ChatGPT to update the registry file.
2. Save only the durable activation meaning to memory.
3. Keep the full registry as the external source of truth.

## Source files used for extraction
- unified-command-mapping(2).docx
- command-cheatsheet(3).pdf
- Cluade secret code(1).pdf
